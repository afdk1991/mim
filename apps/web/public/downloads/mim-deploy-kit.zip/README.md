# Mim 部署工具包（mim-deploy-kit.zip）

> 本包从 Mim 仓库 `deploy/` 目录抽取与生产部署直接相关的核心工件：一次性引导脚本、
> 幂等发布脚本、systemd 服务单元、nginx 站点配置与数据库迁移脚本。
> 打包日期：2026-11-20。本包**不含任何密钥、令牌或 `.env` 取值**；所有机密由服务器侧
> `deploy.sh` 在首次发布时幂等生成 `/opt/mim/mim-api.env`（权限 600），或由管理员手工注入。

## 包内清单

| 路径 | 来源（仓库 `deploy/`） | 用途 |
| --- | --- | --- |
| `bootstrap.sh` | `deploy/bootstrap.sh` | 生产服务器一次性引导：安装基础软件、启用 pnpm、建运行用户与目录、安装 nginx 站点与 systemd 服务、首次发布、尝试签发 HTTPS 证书。幂等，可重复执行。 |
| `deploy.sh` | `deploy/deploy.sh` | 服务器侧幂等发布脚本：拉取 `origin/main` → 安装依赖 → 构建前端 / 管理后台 / 后端 → 发布静态产物 → 生成环境文件 → 执行迁移 → 重启后端 → 健康检查。 |
| `mim-api.service` | `deploy/mim-api.service` | systemd 服务单元：Express + SQLite 后端，`Restart=always`，`EnvironmentFile=/opt/mim/mim-api.env` 缺失即 fail-fast。 |
| `nginx-mim.conf` | `deploy/nginx-mim.conf` | nginx 站点配置：前端静态根、`/admin/` 管理后台、API 与 WebSocket 回环反代。 |
| `migrations/*.cjs` | `deploy/migrations/` | 幂等可重放的数据库迁移 / 清理脚本（三张：fr03 旧表、billing audit 旧表、已下线模块表）。 |

## 部署顺序（root，Linux 服务器）

1. 先在服务器上准备仓库目录（`/opt/mim/app`），代码通过 SSH deploy key 同步；
2. 一次性引导：`sudo bash bootstrap.sh`（可选环境变量见脚本头部注释：`DOMAIN`、`APP_DIR`、`RUN_USER`、`MIM_API_PORT`、`MIM_WEB_HTTP_PORT` 等）；
3. 日常发布：`sudo bash deploy.sh [目标提交]`；不传目标提交时发布 `origin/main` 最新；
4. systemd 单元由引导脚本安装到 `/etc/systemd/system/mim-api.service`；nginx 配置由引导脚本链接到站点目录；
5. 迁移脚本由 `deploy.sh` 在发布流程内自动执行，也可单独 `node migrations/<文件>.cjs` 复核。

## 环境与端口默认值

- 后端回环端口 `8787`（API + WS 共用），环境变量 `MIM_API_PORT` 可调；
- 前端 HTTP 端口 `8088`、HTTPS `443`，环境变量 `MIM_WEB_HTTP_PORT` / `MIM_WEB_HTTPS_PORT` 可调；
- 运行用户 `mim`，应用目录 `/opt/mim/app`，SQLite 库落盘 `services/mim-api/data/`（WAL），数据目录在应用目录之外，发布脚本永不清空；
- 必需机密：`MIM_JWT_SECRET`（≥32 字符）、`MIM_CORS_ORIGINS`、`MIM_ADMIN_TOKEN`，以及可选验证码通道密钥，均经环境文件注入，不写入本包。

## 安全与边界说明

- 本包脚本只引用环境变量名与占位符，未内置任何硬编码密钥、私钥或 `.env` 值；
- `deploy.sh` 对 `/opt/mim/app` 执行 `git reset --hard origin/main`，该目录是纯发布目录，不承载人工修改；本地开发不要在该目录工作；
- 数据库不创建备份（项目策略：不保留任何数据库备份），迁移脚本不调用备份 API；
- 包内未包含平台特定脚本（EdgeOne / GitHub Pages / Cloudflare / IGA / Vercel / Sealos / WordPress 博客脚本），那些属于各静态分发平台或无关站点，详见仓库 `deploy/` 原目录。

## 对应仓库

- 源码仓库：`https://github.com/afdk1991/mim`（Gitee 镜像 `https://gitee.com/mallwm_admin/mim`）
- 生产入口：`https://zy.laal.top`，API `https://api.laal.top`
